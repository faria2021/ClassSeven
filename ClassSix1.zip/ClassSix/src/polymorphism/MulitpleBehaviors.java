package polymorphism;

public class MulitpleBehaviors {

	public static void main(String[] args) {
		sum();
		sum(8);
		sum(4,6);
		sum(8,"eight");
       sum("eight",6);
	}
	public static void sum() {                    //same name
		System.out.println(5+5);
	}
	public static void sum(int x) {
		System.out.println(x+5);
	}
	public static void sum(int a , int b) { //same name=this concept call method overload.meaning a single method getting overload.one method behaving three defferent way.
		//a sigle method getting overloaded.getting made again and again.this concept call in fancy way polymorphism.poly means multipul,having same method multipul times.
		//the difference is the args section ,it only change in args sections.the parametter way.
		//only change is in parametters ways,in the args sections,imput,parameters way.
		//polymorphism means many behavers which is concept of method overlod which basicly means having the same method name,but they are identifiable different ly because of the input value is,
		//what there args are ,whats there valus are.whats there parameters are.
		//they distangush by parameter waise.
		System.out.println(a+b);
	}
	public static void sum(int a , String b) {//Polymorphism/methodoverload,having multiple methods with same name.the rules are:you have to be able to distingusish them by their arguments/parameters/inputs.
		                                     //1.they can not have the same number of arguments with same data type.2.if they have the same number of arguments then their sequence order have to be different.
		System.out.println(a+b);            //return type play no role in this ,only arguments.here all of them are void return type.but not going to work here in polpersime
	}
	
	public static void sum( String b,int a) {
		System.out.println(a+b);
	}
	//public static int sum( String b,int a) {//same method name one is void and other one is int,it not going to work becaue when you call in main there is no distingushish because parameters are same
		//return 10+10;
	//}

                                //but you can do this way in return type.you have to make sure the parameterisation must be different.method name will be same
	public static String sum(String a) {
		return a+a;
	}
}

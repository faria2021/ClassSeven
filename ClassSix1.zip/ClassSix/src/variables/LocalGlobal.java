package variables;

public class LocalGlobal {
	
	String a = "airplane";           //global variable can be static or no static
	static String y ="yell";

	public static void main(String[] args) {
		String a ="Apple";
		int x = 10;
		
		LocalGlobal lg= new LocalGlobal();
		
		String y ="yellow";
		System.out.println(a);
		System.out.println(y);  //you only can pass in what ever in your city.any variable in main they will use this is call local variable
		 test1(y);              //global variable belongs to the class itself.global variable you can create in outside of the methods,outside of your methodand outside of main method.
		 test2();          
		

	}
     
	public static void test1(String a) { //oops concept (object oriented prog):4 pillars;;;;Abstractions,polymorphism,inheritance,Encapsulation.APIE.Poly=multiple//Morphism=behaviors.
		String y ="yield";
	    a ="ant";
		System.out.println(a);
		System.out.println(y);
	}
	
	public static void test2() {
		String a ="Air";
		String z ="yard";
		System.out.println(a);
		System.out.println(z);
		
	}
}

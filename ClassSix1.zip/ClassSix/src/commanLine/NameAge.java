package commanLine;

public class NameAge {

	public static void main(String[] args) { //this is a lagecy code.althe way to the old version of java.now two option you can use it or not .if you want to use you have to 
		                          //go to run configaration option and put the values one args option  .thats how you can use the args methods .and it depends on the users
		
		System.out.println(args[1]);
		
	
		
		
		
		
		
		
		
		//String names[] = {"sadia", "shakir","suraj"};

	//System.out.println(names[1]);
	
	//arraytest1(names);  //when you passing the array or calling the array method,you dont have put the array symbol[] in the main method,the system already knows this is an array.
                        //you dont have said again that this is an array because the system already knows thats an array.
	//	}
//	public static void arrayTest(String name) {
//		System.out.println(name);
//		}
	
	//public static void arraytest1(String[] students) {
		//System.out.println(students[2]);
	}
}
